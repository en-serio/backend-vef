<!-- Table example que cargará cuando demos a gestionar transfers -->
<h2>Gestión de transfers</h2>
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Juan Pérez</td>
                            <td>2024-10-21</td>
                            <td><button class="btn btn-sm btn-primary">Ver</button></td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>María López</td>
                            <td>2024-10-20</td>
                            <td><button class="btn btn-sm btn-primary">Ver</button></td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Carlos Martínez</td>
                            <td>2024-10-19</td>
                            <td><button class="btn btn-sm btn-primary">Ver</button></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>