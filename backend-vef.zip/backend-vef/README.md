# backend-vef
Repositorio educativo de backend php
## Equipo de Desarrollo
Somos un equipo formado por 3 personas trabajando en un proyecto educativo de PHP.