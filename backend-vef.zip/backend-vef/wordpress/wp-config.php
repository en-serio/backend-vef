<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'wordpress_user' );

/** Database password */
define( 'DB_PASSWORD', 'wordpress_password' );

/** Database hostname */
define( 'DB_HOST', 'my_mysql' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'cKLuItE1h VkI4L@CmO>IeSUIP`#Ngj!|r^~Fl;4fN$~fLmML/t=[%[(f~q:v}]b' );
define( 'SECURE_AUTH_KEY',  '?|R8iUnb$iTKZnRTWhX(!L~uTF w8klJJS@6_V~H1eoA:n4k}F%@>M^^<=A*&=EX' );
define( 'LOGGED_IN_KEY',    ',2UXP]C(Vhu%!6Ch^9&nCTP3K;V*^=ow}avdF.R8E2O.dcWKO %[P;8QfSbz=m@Z' );
define( 'NONCE_KEY',        '666=,iTPg&c>Ht8aVZ[TGD0zrnvxE6x~w`hA5?7*gledhfTs5.Ac7CXpUd9u/N:;' );
define( 'AUTH_SALT',        'mA$nfmuk<%#_[5h;%j2|r?Usm^Z8^+A{[kr@H=FL.=S9?i7;hk)O3b<Hg?,u@-``' );
define( 'SECURE_AUTH_SALT', 'fBl`<*p/pP/%/ENu@8@DWNUU*[8`AC#?t8xb4VPe?Ojf~wkM~N`ckhKgvT%?>yG(' );
define( 'LOGGED_IN_SALT',   'r1TF.K{;JA>O:?iEm7b9q+Mjf&QzP*~IaEUT/xe+Qd1Q$wnL/]b[>Dn?Aq4J&_L0' );
define( 'NONCE_SALT',       'RmqEt5n)yXgnZgH0Cvb+Wh2e019~X}FhTK*)V>bwIRPtAK`v5yZW))ih;`NAZ/Jm' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
