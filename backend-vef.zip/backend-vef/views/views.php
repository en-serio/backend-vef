<h2>Calendario de transfers</h2>
    <div id="calendar-container" class="mx-auto">
        <div id="calendar"></div>
    </div>

